// Auto-generated preloaded sounds hook
window.__PRELOADED_CUSTOM_SOUNDS__ = window.__PRELOADED_CUSTOM_SOUNDS__ || {};
