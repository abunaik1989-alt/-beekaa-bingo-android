package com.beekaabingo.caller;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class NativeBingoActivity extends Activity implements TextToSpeech.OnInitListener {

    private TextView currentCallTextView;
    private Button nextBallButton;
    private Button resetButton;
    private Spinner timeSpinner;
    private ToggleButton autoToggleButton;
    private GridView boardGridView;

    private TextToSpeech tts;
    private List<Integer> availableBalls = new ArrayList<>();
    private Random random = new Random();
    private boolean[] calledNumbers = new boolean[76];
    private BoardAdapter boardAdapter;

    private Handler handler = new Handler();
    private Runnable autoCallRunnable;
    private int currentIntervalMs = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native_bingo);

        tts = new TextToSpeech(this, this);

        currentCallTextView = findViewById(R.id.currentCallTextView);
        nextBallButton = findViewById(R.id.nextBallButton);
        resetButton = findViewById(R.id.resetButton);
        timeSpinner = findViewById(R.id.timeSpinner);
        autoToggleButton = findViewById(R.id.autoToggleButton);
        boardGridView = findViewById(R.id.boardGridView);

        String[] speedOptions = {"3 Seconds", "5 Seconds", "8 Seconds"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, speedOptions);
        timeSpinner.setAdapter(adapter);
        timeSpinner.setSelection(1);

        boardAdapter = new BoardAdapter();
        boardGridView.setAdapter(boardAdapter);

        autoCallRunnable = new Runnable() {
            @Override
            public void run() {
                callNextBall();
                if (!availableBalls.isEmpty() && autoToggleButton.isChecked()) {
                    handler.postDelayed(this, currentIntervalMs);
                } else if (availableBalls.isEmpty()) {
                    autoToggleButton.setChecked(false);
                }
            }
        };

        autoToggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    int pos = timeSpinner.getSelectedItemPosition();
                    if (pos == 0) currentIntervalMs = 3000;
                    else if (pos == 1) currentIntervalMs = 5000;
                    else currentIntervalMs = 8000;

                    nextBallButton.setEnabled(false);
                    handler.post(autoCallRunnable);
                } else {
                    handler.removeCallbacks(autoCallRunnable);
                    nextBallButton.setEnabled(true);
                }
            }
        });

        nextBallButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callNextBall();
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });

        resetGame();
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && tts != null) {
            tts.setLanguage(Locale.US);
        }
    }

    private void callNextBall() {
        if (availableBalls.isEmpty()) {
            currentCallTextView.setText("End");
            nextBallButton.setEnabled(false);
            if (autoToggleButton.isChecked()) {
                autoToggleButton.setChecked(false);
            }
            return;
        }

        int index = random.nextInt(availableBalls.size());
        int ballNumber = availableBalls.get(index);
        availableBalls.remove(index);

        calledNumbers[ballNumber] = true;
        boardAdapter.notifyDataSetChanged();

        String letter;
        if (ballNumber <= 15) letter = "B";
        else if (ballNumber <= 30) letter = "I";
        else if (ballNumber <= 45) letter = "N";
        else if (ballNumber <= 60) letter = "G";
        else letter = "O";

        String callText = letter + "-" + ballNumber;
        currentCallTextView.setText(callText);

        if (tts != null) {
            tts.speak(letter + " " + ballNumber, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    private void resetGame() {
        if (autoToggleButton != null) {
            autoToggleButton.setChecked(false);
        }
        handler.removeCallbacks(autoCallRunnable);

        availableBalls.clear();
        for (int i = 1; i <= 75; i++) {
            availableBalls.add(i);
            calledNumbers[i] = false;
        }

        currentCallTextView.setText("Ready");
        nextBallButton.setEnabled(true);
        if (boardAdapter != null) {
            boardAdapter.notifyDataSetChanged();
        }
    }

    private class BoardAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return 75;
        }

        @Override
        public Object getItem(int position) {
            return position + 1;
        }

        @Override
        public long getItemId(int position) {
            return position + 1;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView textView;
            if (convertView == null) {
                textView = new TextView(NativeBingoActivity.this);
                textView.setLayoutParams(new GridView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, 80));
                textView.setGravity(Gravity.CENTER);
                textView.setTextSize(16);
            } else {
                textView = (TextView) convertView;
            }

            int num = position + 1;
            textView.setText(String.valueOf(num));

            if (calledNumbers[num]) {
                textView.setBackgroundColor(Color.parseColor("#10B981")); // Emerald Green
                textView.setTextColor(Color.WHITE);
            } else {
                textView.setBackgroundColor(Color.parseColor("#334155")); // Slate 700
                textView.setTextColor(Color.parseColor("#CBD5E1")); // Slate 300
            }

            return textView;
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(autoCallRunnable);
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
