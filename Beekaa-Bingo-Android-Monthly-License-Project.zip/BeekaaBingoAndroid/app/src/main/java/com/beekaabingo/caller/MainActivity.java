package com.beekaabingo.caller;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Toast;
import androidx.webkit.WebViewAssetLoader;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Locale;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.nio.charset.StandardCharsets;
import java.security.Signature;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {

    private WebView webView;
    private TextToSpeech tts;
    private Vibrator vibrator;
    private PowerManager.WakeLock wakeLock;
    private final Handler licenseHandler = new Handler(Looper.getMainLooper());
    private final Runnable licenseMonitor = new Runnable() {
        @Override public void run() {
            if (webView != null && !hasValidStoredLicense()) {
                webView = null;
                showLicenseGate("Your Beekaa Bingo license has expired or is invalid. Please renew to continue.");
            } else if (webView != null) {
                licenseHandler.postDelayed(this, 60_000L);
            }
        }
    };

    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 2001;
    private static final int LICENSE_FILE_REQUEST = 2002;
    private static final String LICENSE_PREFS = "beekaa_license_store";
    private static final String LICENSE_JSON = "license_json";
    private static final String INSTALLATION_ID = "installation_id";
    private static final String LAST_SEEN = "last_seen_ms";
    private static final String PUBLIC_KEY_B64 = "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAyIW0aHK8bzjnTGROX5O4W113Hi1DvzjMJvTzi8ZEUFm7lkFeF2igmbWxK0jZr2JuRHnBriwcP9PgAihUlKSA/etnmXYLO1LdQrUwdjF92+dqqbN+/C+jIRS6JMg1bKGbt1dHTde6JzIElVPhW7tC0f+ymbkx27uP38MFScp5RRApdmjsZL+YHWg/4rPNWjh3EIlHLbUyzZRPynlzBC7i9Bwq9ms+eMJAuLLYKt+lmpib84JSy4Jm53oAbA6wdSGO/WPYRLfm93FIEpbyllST1lhUeqeWtbjgFU4bRqO8Jb2Qpdi1jzzSnfv+rNDoLcHXhp/BdHlTy5b8q96FhDS7r4r7yDKU8myYx+7J9KAxCLtE4ZYePiLZa5uTxBp4a8Y/ANxl3iwOvv2EomVcPsvEM4T9DUkitbqKhs0d0kxZLHCbuyBR/mPeRgiI4TV3yGVxK1KJRsjp3tHSe+gNY8gxgUzcJw3BA1582O8jF5kTDwAi5cI8Q7DQiW6Ot0SoNEZjAgMBAAE=";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!hasValidStoredLicense()) {
            showLicenseGate("Activate Beekaa Bingo to continue.");
            return;
        }
        startLicensedApp();
    }

    private void startLicensedApp() {
        // 1. Keep screen awake via WindowManager
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // 2. Hardware WakeLock via PowerManager
        try {
            PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ON_AFTER_RELEASE, "BeekaaBingo:WakeLock");
                if (!wakeLock.isHeld()) {
                    wakeLock.acquire();
                }
            }
        } catch (Exception ignored) {}

        // 3. Request Storage and Audio Permissions at runtime
        requestAllStoragePermissions();

        // 4. Enable Immersive Fullscreen Mode
        hideSystemUI();

        // 5. Native Hardware Services
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        tts = new TextToSpeech(this, this);

        // Layout setup
        FrameLayout container = new FrameLayout(this);
        container.setBackgroundColor(0xFF0F172A); // slate-900

        webView = new WebView(this);
        container.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));
        setContentView(container);

        // Configure Offline WebView Settings
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        // Setup Android JS Bridge
        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        // WebChromeClient with onShowFileChooser for bulk & single file uploads
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;

                Intent intent = params.createIntent();
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "No file manager found", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        // Download Listener to save downloaded ZIP bundles and data files to Downloads folder
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                if (!url.startsWith("blob:") && !url.startsWith("data:")) {
                    try {
                        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                        request.setMimeType(mimeType);
                        request.setDescription("Downloading Beekaa Bingo file...");
                        String filename = URLUtil.guessFileName(url, contentDisposition, mimeType);
                        request.setTitle(filename);
                        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
                        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                        if (dm != null) dm.enqueue(request);
                        Toast.makeText(MainActivity.this, "Downloading " + filename + " to Downloads", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Download error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Modern WebViewAssetLoader for local offline file loading
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideSystemUI();
            }
        });

        // Load offline packaged web bundle
        webView.loadUrl("file:///android_asset/www/index.html");
        licenseHandler.removeCallbacks(licenseMonitor);
        licenseHandler.postDelayed(licenseMonitor, 60_000L);
    }

    private SharedPreferences licensePrefs() {
        return getSharedPreferences(LICENSE_PREFS, MODE_PRIVATE);
    }

    private String getInstallationId() {
        SharedPreferences prefs = licensePrefs();
        String id = prefs.getString(INSTALLATION_ID, null);
        if (id == null || id.trim().isEmpty()) {
            String compact = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase(Locale.US);
            id = "BEEKA-" + compact;
            prefs.edit().putString(INSTALLATION_ID, id).apply();
        }
        return id;
    }

    private boolean hasValidStoredLicense() {
        String raw = licensePrefs().getString(LICENSE_JSON, null);
        if (raw == null) return false;
        try {
            JSONObject envelope = new JSONObject(raw);
            JSONObject payload = envelope.getJSONObject("payload");
            if (validateEnvelope(envelope, payload) != null) return false;
            long now = System.currentTimeMillis();
            long lastSeen = licensePrefs().getLong(LAST_SEEN, 0L);
            if (lastSeen > 0 && now < lastSeen - 5 * 60 * 1000L) return false;
            licensePrefs().edit().putLong(LAST_SEEN, Math.max(now, lastSeen)).apply();
            return true;
        } catch (Exception e) { return false; }
    }

    private String validateEnvelope(JSONObject envelope, JSONObject payload) {
        try {
            if (!"beekaa-bingo-caller".equals(payload.optString("productId"))) return "This license is for a different product.";
            if (payload.optInt("licenseVersion", 0) != 1) return "Unsupported license version.";
            if (!getInstallationId().equalsIgnoreCase(payload.optString("installationId"))) return "This license belongs to a different phone installation.";
            long issued = parseIsoDate(payload.optString("issuedAt"));
            long expires = parseIsoDate(payload.optString("expiresAt"));
            long now = System.currentTimeMillis();
            if (issued <= 0 || expires <= 0) return "The license dates are invalid.";
            if (issued > now + 5 * 60 * 1000L) return "The phone date is earlier than the license issue date.";
            if (expires < now) return "This monthly license has expired. Please renew it.";
            String sigText = envelope.optString("signature", "");
            if (sigText.isEmpty()) return "The license signature is missing.";
            PublicKey publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(android.util.Base64.decode(PUBLIC_KEY_B64, android.util.Base64.DEFAULT)));
            Signature verifier = Signature.getInstance("SHA256withRSA");
            verifier.initVerify(publicKey);
            verifier.update(stableJson(payload).getBytes(StandardCharsets.UTF_8));
            if (!verifier.verify(android.util.Base64.decode(sigText, android.util.Base64.DEFAULT))) return "The license signature is invalid.";
            return null;
        } catch (Exception e) { return "The license file could not be verified."; }
    }

    private long parseIsoDate(String value) {
        try {
            java.text.SimpleDateFormat withMillis = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            withMillis.setLenient(false);
            withMillis.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return withMillis.parse(value).getTime();
        } catch (Exception e) {
            try {
                java.text.SimpleDateFormat withoutMillis = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                withoutMillis.setLenient(false);
                withoutMillis.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                return withoutMillis.parse(value).getTime();
            } catch (Exception ignored) { return -1L; }
        }
    }

    private String stableJson(Object value) throws Exception {
        if (value == null || value == JSONObject.NULL) return "null";
        if (value instanceof JSONObject) {
            JSONObject object = (JSONObject) value;
            List<String> keys = new ArrayList<>();
            Iterator<String> it = object.keys();
            while (it.hasNext()) keys.add(it.next());
            Collections.sort(keys);
            StringBuilder out = new StringBuilder("{");
            for (int i = 0; i < keys.size(); i++) {
                if (i > 0) out.append(',');
                String key = keys.get(i);
                out.append(JSONObject.quote(key)).append(':').append(stableJson(object.get(key)));
            }
            return out.append('}').toString();
        }
        if (value instanceof JSONArray) {
            JSONArray array = (JSONArray) value;
            StringBuilder out = new StringBuilder("[");
            for (int i = 0; i < array.length(); i++) {
                if (i > 0) out.append(',');
                out.append(stableJson(array.get(i)));
            }
            return out.append(']').toString();
        }
        if (value instanceof String) return JSONObject.quote((String) value);
        return String.valueOf(value);
    }

    private void showLicenseGate(String message) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 32, 28, 32);
        root.setBackgroundColor(Color.rgb(15, 23, 42));
        ScrollView scroll = new ScrollView(this);
        TextView title = new TextView(this);
        title.setText("BEEKAA BINGO"); title.setTextColor(Color.WHITE); title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); title.setGravity(Gravity.CENTER); title.setPadding(0, 24, 0, 20);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView description = new TextView(this);
        description.setText(message + "\n\nThis app is rented monthly and works offline after activation. Send the Installation ID below to the provider and request a license file.");
        description.setTextColor(Color.rgb(226, 232, 240)); description.setTextSize(16); description.setGravity(Gravity.CENTER); description.setPadding(0, 0, 0, 24);
        root.addView(description, new LinearLayout.LayoutParams(-1, -2));
        TextView label = new TextView(this); label.setText("YOUR INSTALLATION ID"); label.setTextColor(Color.rgb(148, 163, 184)); label.setTextSize(13); label.setGravity(Gravity.CENTER);
        root.addView(label, new LinearLayout.LayoutParams(-1, -2));
        TextView id = new TextView(this); id.setText(getInstallationId()); id.setTextColor(Color.WHITE); id.setTextSize(21); id.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); id.setGravity(Gravity.CENTER); id.setPadding(0, 10, 0, 24);
        root.addView(id, new LinearLayout.LayoutParams(-1, -2));
        Button share = new Button(this); share.setText("Send Installation ID to Provider");
        share.setOnClickListener(v -> {
            Intent send = new Intent(Intent.ACTION_SEND); send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, "Beekaa Bingo activation request");
            send.putExtra(Intent.EXTRA_TEXT, "Please issue or renew my Beekaa Bingo monthly license. Installation ID: " + getInstallationId());
            startActivity(Intent.createChooser(send, "Send Installation ID"));
        });
        root.addView(share, new LinearLayout.LayoutParams(-1, -2));
        Button importButton = new Button(this); importButton.setText("Import License File");
        importButton.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("application/json");
            try { startActivityForResult(pick, LICENSE_FILE_REQUEST); }
            catch (Exception e) { Toast.makeText(this, "Unable to open file picker", Toast.LENGTH_SHORT).show(); }
        });
        root.addView(importButton, new LinearLayout.LayoutParams(-1, -2));
        TextView note = new TextView(this); note.setText("A license is valid only for this app installation and expires on the date set by the provider.");
        note.setTextColor(Color.rgb(148, 163, 184)); note.setTextSize(13); note.setGravity(Gravity.CENTER); note.setPadding(0, 24, 0, 0);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
        scroll.addView(root); setContentView(scroll);
    }

    private void handleLicenseFile(Uri uri) {
        try (java.io.InputStream in = getContentResolver().openInputStream(uri)) {
            if (in == null) throw new Exception("Cannot read selected file.");
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buffer = new byte[4096]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
            String raw = out.toString("UTF-8");
            JSONObject envelope = new JSONObject(raw); JSONObject payload = envelope.getJSONObject("payload");
            String reason = validateEnvelope(envelope, payload);
            if (reason != null) { showLicenseGate(reason); return; }
            long now = System.currentTimeMillis(); long lastSeen = licensePrefs().getLong(LAST_SEEN, 0L);
            if (lastSeen > 0 && now < lastSeen - 5 * 60 * 1000L) { showLicenseGate("Please correct your phone date and import the license again."); return; }
            licensePrefs().edit().putString(LICENSE_JSON, raw).putLong(LAST_SEEN, Math.max(now, lastSeen)).apply();
            Toast.makeText(this, "License activated successfully", Toast.LENGTH_LONG).show();
            recreate();
        } catch (Exception e) {
            Toast.makeText(this, "Invalid license file. Select the JSON license sent by your provider.", Toast.LENGTH_LONG).show();
            showLicenseGate("The license file could not be read. Please select the correct JSON file.");
        }
    }

    private void requestAllStoragePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(new String[]{
                    Manifest.permission.READ_MEDIA_AUDIO,
                    Manifest.permission.READ_MEDIA_IMAGES
            }, 101);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            }, 101);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    ClipData clipData = data.getClipData();
                    if (clipData != null) {
                        int count = clipData.getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = clipData.getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{ data.getData() };
                    }
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        } else if (requestCode == LICENSE_FILE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            handleLicenseFile(data.getData());
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null && !hasValidStoredLicense()) {
            webView = null;
            showLicenseGate("Your Beekaa Bingo license has expired or is invalid. Please renew to continue.");
        }
    }

    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUI();
        }
    }

    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS && tts != null) {
            tts.setLanguage(Locale.US);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        licenseHandler.removeCallbacks(licenseMonitor);
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {}
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void vibrate(long milliseconds) {
            if (vibrator == null) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(VibrationEffect.createOneShot(milliseconds, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vibrator.vibrate(milliseconds);
            }
        }

        @JavascriptInterface
        public void speak(String text) {
            if (tts != null) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "BEE_CALL");
            }
        }

        @JavascriptInterface
        public void launchNativeCaller() {
            Intent intent = new Intent(MainActivity.this, NativeBingoActivity.class);
            startActivity(intent);
        }

        @JavascriptInterface
        public boolean isOfflineNative() {
            return true;
        }

        @JavascriptInterface
        public void saveBase64ToDownloads(String base64Data, String fileName, String mimeType) {
            try {
                byte[] bytes = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);
                File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!path.exists()) path.mkdirs();
                File file = new File(path, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(bytes);
                fos.close();
                Toast.makeText(MainActivity.this, "Saved: " + fileName + " in Downloads", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Error saving: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
