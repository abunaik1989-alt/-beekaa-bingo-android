#!/usr/bin/env bash
echo "Building Beekaa Bingo Offline Android APK..."
if command -v ./gradlew &> /dev/null; then
    ./gradlew assembleDebug
    echo "APK created at: app/build/outputs/apk/debug/app-debug.apk"
else
    echo "Gradle wrapper not initialized. Please open in Android Studio or run 'gradle assembleDebug'."
fi
