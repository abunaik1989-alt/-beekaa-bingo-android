# Beekaa Bingo Caller — Android Offline Rental Build

This is the Android wrapper for Beekaa Bingo Caller. The web app is packaged locally in `app/src/main/assets/www/`, so normal bingo use does not require a domain, website, or internet connection.

## Monthly rental protection

- The first launch shows an activation screen and a unique Installation ID.
- The customer shares that ID with the app provider after paying.
- The provider generates a digitally signed `*.json` license for that ID and an expiry date.
- The customer imports the JSON file in the app. The license is verified on the phone using an embedded public key; no internet is required.
- The app checks expiry on launch/resume and periodically while open. Expired licenses return to the activation screen.
- A license is for one app installation. Reinstalling the app or clearing its app data can generate a new ID and require a replacement license.

**Important limitation:** an offline app cannot be perfectly tamper-proof. Device-clock manipulation, rooting, or APK modification may bypass some controls. The app includes a basic clock-rollback check, but it is not a substitute for online validation.

## Build the APK on Windows, macOS, or Linux

1. Install Android Studio and its Android SDK (API 34 or compatible).
2. Open this `BeekaaBingoAndroid` folder in Android Studio.
3. Allow Gradle sync to finish. Internet may be required for the first dependency download.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. For a test build, use `app/build/outputs/apk/debug/app-debug.apk`.
6. For customer distribution, create a signed release APK in **Build → Generate Signed Bundle / APK**. Keep the signing key private and back it up securely.

## Monthly customer workflow

1. Customer installs the APK and opens it offline.
2. Customer taps **Send Installation ID to Provider** and sends you the displayed ID.
3. Confirm payment.
4. Use the owner-only license generator to create a license with the customer's Installation ID and expiry date.
5. Send only the generated license JSON file to the customer.
6. Customer opens Beekaa Bingo → **Import License File** → selects the JSON file.
7. For renewal, create a new license for the same Installation ID with a new expiry date.

## Owner security

Never send `private.pem`, the owner license kit, or the full source project to customers. The app only contains the public verification key. Send customers the signed APK and their individual license file only.

The project contains an existing packaged offline web bundle. If you change the original web app, rebuild/copy its updated files into `app/src/main/assets/www/` before building the APK.
